import json
import boto3
import os
from datetime import datetime, date

def handler(event, context):
    """
    Lambda function to handle visitor counter and analytics
    """
    try:
        # Initialize DynamoDB
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(os.environ['DYNAMODB_TABLE'])
        
        # Get current date for daily counter
        today = date.today().isoformat()
        
        # Update total visitor count
        try:
            response = table.get_item(
                Key={'id': 'total_visitors', 'category': 'analytics'}
            )
            if 'Item' in response:
                total_count = response['Item'].get('count', 0) + 1
            else:
                total_count = 1
                
            table.put_item(Item={
                'id': 'total_visitors',
                'category': 'analytics',
                'count': total_count,
                'last_updated': datetime.utcnow().isoformat()
            })
        except Exception as e:
            print(f"Error updating total count: {str(e)}")
            total_count = 1
        
        # Update daily visitor count
        try:
            response = table.get_item(
                Key={'id': f'daily_visitors_{today}', 'category': 'analytics'}
            )
            if 'Item' in response:
                daily_count = response['Item'].get('count', 0) + 1
            else:
                daily_count = 1
                
            table.put_item(Item={
                'id': f'daily_visitors_{today}',
                'category': 'analytics',
                'count': daily_count,
                'date': today,
                'last_updated': datetime.utcnow().isoformat(),
                'ttl': int(datetime.utcnow().timestamp()) + (30 * 24 * 60 * 60)  # 30 days TTL
            })
        except Exception as e:
            print(f"Error updating daily count: {str(e)}")
            daily_count = 1
        
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
            },
            'body': json.dumps({
                'total_visitors': total_count,
                'today_visitors': daily_count,
                'date': today
            })
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
            },
            'body': json.dumps({
                'error': 'Internal server error'
            })
        }
